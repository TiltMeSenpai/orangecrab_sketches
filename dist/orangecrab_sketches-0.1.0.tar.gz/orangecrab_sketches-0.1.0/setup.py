# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['orangecrab_sketches']

package_data = \
{'': ['*']}

install_requires = \
['nmigen @ git+git://github.com/nmigen/nmigen@master',
 'nmigen-boards @ git+git://github.com/nmigen/nmigen-boards@master',
 'yowasp-nextpnr-ecp5-25k',
 'yowasp-yosys']

setup_kwargs = {
    'name': 'orangecrab-sketches',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Josh Koike',
    'author_email': 'jk@tilting.me',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
