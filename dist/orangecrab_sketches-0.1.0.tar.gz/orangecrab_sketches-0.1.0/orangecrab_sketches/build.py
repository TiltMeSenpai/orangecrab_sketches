from nmigen_boards.orangecrab_r0_2 import OrangeCrabR0_2Platform

from .top import Main

if __name__ == "__main__":
    OrangeCrabR0_2Platform().build(Main(), do_program=True)